@include ('admin.includes.header')
	@yield('content')
@include ('admin.includes.footer')