@if(Auth::check())
	</div>
</div>
	<div class="container-fluid container-fixed-lg footer">
	    <div class="copyright sm-text-center">
	        <p class="small no-margin pull-left sm-pull-reset">
	            <span class="hint-text">Copyright &copy; <?php echo date('Y'); ?> </span>
	            <span class="font-montserrat">{{ Config::get('app.name') }}.</span>
	            <span class="hint-text">All rights reserved. </span>
	            <span class="sm-block"><a href="#" class="m-l-10 m-r-10">Terms of use</a> <span class="muted">|</span> <a href="#" class="m-l-10">Privacy Policy</a></span>
	        </p>
	        <p class="small no-margin pull-right sm-pull-reset">
	            Hand-crafted <span class="hint-text">&amp; made with Love in</span> <img class="footer-flag" src="{{ URL::asset('backend/img/india-flag-icon-16.png') }}">
	        </p>
	    </div>
	</div>
</div>
@endif

<script src="{{ URL::asset('backend/plugins/feather-icons/feather.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/pace/pace.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/modernizr.custom.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-ui/jquery-ui.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/popper/umd/popper.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery/jquery-easy.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-unveil/jquery.unveil.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-ios-list/jquery.ioslist.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-actual/jquery.actual.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-scrollbar/jquery.scrollbar.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/select2/js/select2.full.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/classie/classie.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/switchery/js/switchery.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/lib/d3.v3.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/nv.d3.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/utils.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/tooltip.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/interactiveLayer.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/models/axis.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/models/line.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/models/lineWithFocusChart.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/rickshaw/rickshaw.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/mapplic/js/hammer.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/mapplic/js/jquery.mousewheel.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/mapplic/js/mapplic.js') }}" type="text/javascript"></script>

<script src="{{ URL::asset('backend/plugins/jquery-datatable/media/js/jquery.dataTables.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-datatable/media/js/dataTables.bootstrap.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-datatable/extensions/Bootstrap/jquery-datatable-bootstrap.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/datatables-responsive/js/datatables.responsive.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/datatables-responsive/js/lodash.min.js') }}" type="text/javascript"></script>

<script src="{{ URL::asset('backend/js/dashboard.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/js/pages.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/js/scripts.js') }}" type="text/javascript"></script>
</body>
</html>