@if(Auth::check())
	</div>
</div>
</div>
@endif

<script src="{{ URL::asset('backend/plugins/feather-icons/feather.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/pace/pace.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/modernizr.custom.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-ui/jquery-ui.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/popper/umd/popper.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/bootstrap/js/bootstrap.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery/jquery-easy.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-unveil/jquery.unveil.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-ios-list/jquery.ioslist.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-actual/jquery.actual.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-scrollbar/jquery.scrollbar.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/select2/js/select2.full.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/classie/classie.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/switchery/js/switchery.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/lib/d3.v3.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/nv.d3.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/utils.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/tooltip.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/interactiveLayer.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/models/axis.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/models/line.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/nvd3/src/models/lineWithFocusChart.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/rickshaw/rickshaw.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/mapplic/js/hammer.min.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/mapplic/js/jquery.mousewheel.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/mapplic/js/mapplic.js') }}" type="text/javascript"></script>


<script src="{{ URL::asset('backend/plugins/jquery-datatable/media/js/jquery.dataTables.min.js') }}" type="text/javascript"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js" type="text/javascript"></script>

<script src="{{ URL::asset('backend/plugins/jquery-datatable/media/js/jquery.dataTables.min.js') }}" type="text/javascript"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/dataTables.buttons.min.js" type="text/javascript"></script>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js" type="text/javascript"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.2/js/buttons.html5.min.js" type="text/javascript"></script>

<script src="{{ URL::asset('backend/plugins/jquery-datatable/media/js/dataTables.bootstrap.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/jquery-datatable/extensions/Bootstrap/jquery-datatable-bootstrap.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/datatables-responsive/js/datatables.responsive.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/plugins/datatables-responsive/js/lodash.min.js') }}" type="text/javascript"></script>

<script src="{{ URL::asset('backend/js/dashboard.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/js/pages.js') }}" type="text/javascript"></script>
<script src="{{ URL::asset('backend/js/scripts.js') }}" type="text/javascript"></script>
</body>
</html>