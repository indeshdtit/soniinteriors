<?php
    return [
        'user_role' => [
            'super_admin' => 1,
            'admin' => 2
        ],
        'status' => [
            'inactive' => 0,
            'active' => 1,
            'completed' => 2
        ],
        'invoice_number' => 10000
    ];
?>