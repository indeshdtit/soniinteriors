<?php

namespace App\Http\Controllers\admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Helpers\Dtit;
use App\Models\Admin\Category;
use Route;

class CategoriesController extends Controller
{
    public function index()
    {
        $data['page_title'] = 'Categories';
        $data['list'] = Category::list_all();

        return view('admin.categories.index', $data);
    }

    public function sub_categories()
    {
        $data['page_title'] = 'Sub-Categories';
        $data['parent_id'] = Route::current()->parameter('category_id');
        $data['list'] = Category::list_all($data['parent_id']);
        
        return view('admin.categories.sub_categories', $data);
    }

    public function add_category(Request $request)
    {
        if ($request->isMethod('post'))
        {
            $validator = $request->validate([
                'category_name' => 'required|string|max:255',
	            'parent_id' => 'required|max:255',
	            'status' => 'required'
            ]);

            $category = Category::create([
                'category_name' => $request->post('category_name'),
                'parent_id' => $request->post('parent_id'),
                'status' => $request->post('status')
            ]);

            Dtit::flash('Category added successfully.');
            return redirect()->route('admin_edit_category', $category->id);
        }

        $data['page_title'] = 'Add Category';
        $data['categories'] = Category::list_all();

        return view('admin.categories.add', $data);
    }

    public function edit_category(Request $request)
    {
    	$id = Route::current()->parameter('id');
    	if ($request->isMethod('post'))
        {
	        $validator = $request->validate([
	            'category_name' => 'required|string|max:255',
	            'parent_id' => 'required|max:255',
	            'status' => 'required'
	        ]);

	    	if(Category::modify_category($id, $request->post(), 'update'))
			{
	            Dtit::flash('Category updated successfully.');
	        }
	        else
	        {
	            Dtit::flash('Error while updating category. Please try again.', 'danger');
	        }

	    	return redirect()->back();
        }

        $data['page_title'] = 'Edit Category';
        $data['categories'] = Category::list_all();
        $data['details'] = Category::findOrFail($id);
        $data['sub_categories'] = Category::list_all($id);

        return view('admin.categories.edit', $data);
    }

    public function delete_category(Request $request)
    {
        if(Category::modify_category(Route::current()->parameter('id'), array(), 'delete'))
        {
            Dtit::flash('Category deleted successfully.');
        }
        else
        {
            Dtit::flash('Error while deleting category. Please try again.', 'danger');
        }

    	return redirect()->back();
    }
}
