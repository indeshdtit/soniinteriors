<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Hash;
use Route;
use Config;
use App\Helpers\Dtit;
use App\Models\Admin\Order;

class OrdersController extends Controller
{
    public function index()
    {        
        $data['page_title'] = 'Order List';
        $data['list'] = Order::list_all();

        return view('admin.orders.index', $data);
    }

    public function add_order(Request $request)
    {
        if ($request->isMethod('post'))
        {
            // $validator = $request->validate([
            //     'date_written' => 'required|string|email|max:255|unique:users',
            //     'password' => 'required|string|min:6',
            //     'status' => 'required'
            // ]);

            $order_number = Config::get('invoice_number');
            $highest_order_number = Order::select('order_number')->orderBy('id', 'DESC')->first();
            if ($highest_order_number)
            {
                $order_number = $highest_order_number->order_number+1;
            }

            $post_data = $request->post();

            $order = new Order();
            $order->order_number = $order_number;
            $order->date_written = $post_data['date_written'] ? date('Y-m-d H:i:s', strtotime($post_data['date_written'])) : null;
            $order->origination_id = $post_data['origination'];
            $order->date_picked_up = $post_data['date_picked_up'] ? date('Y-m-d H:i:s', strtotime($post_data['date_picked_up'])) : null;
            $order->order_picked_up_at = $post_data['order_picked_up_at'];
            $order->is_partial_order = $post_data['is_partial_order'];
            $order->status = $post_data['status'];
            
            if ($order->save())
            {
                Dtit::flash('Order added successfully.');
                return redirect()->route('admin_edit_order', $order->id);
            }
            else
            {
                Dtit::flash('Error while adding order. Please try again.', 'danger');
            }
        }

        $data['picked_up_at'] = \App\Models\Admin\PickedUpAt::get();
        $data['originations'] = \App\Models\Admin\Origination::get();

        $data['page_title'] = 'Add Order';
        return view('admin.orders.add', $data);
    }

    public function edit_order(Request $request)
    {
        $data['page_title'] = 'Edit Order';
        $data['picked_up_at'] = \App\Models\Admin\PickedUpAt::get();
        $data['originations'] = \App\Models\Admin\Origination::get();

        $data['order_details'] = Order::findOrFail(Route::current()->parameter('order_id'));

        return view('admin.orders.edit', $data);
    }

    public function update_order(Request $request)
    {
        $id = Route::current()->parameter('order_id');

        $validator = $request->validate([
            'name' => 'required|string|max:255',
            'email' => 'required|string|max:255|unique:users,email,' . $id,
            'status' => 'required'
        ]);

    	if(User::modify_user($id, $request->post(), 'update'))
		{
            Dtit::flash('User updated successfully.');
        }
        else
        {
            Dtit::flash('Error while updating user. Please try again.', 'danger');
        }

    	return redirect()->back();
    }

    public function delete_order(Request $request)
    {
        if(Order::modify_order(Route::current()->parameter('order_id'), array(), 'delete'))
        {
            Dtit::flash('Order deleted successfully.');
        }
        else
        {
            Dtit::flash('Error while deleting order. Please try again.', 'danger');
        }

    	return redirect()->back();
    }
}