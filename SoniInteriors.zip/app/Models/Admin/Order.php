<?php

namespace App\Models\Admin;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;
use Config;

class Order extends Model
{
	use SoftDeletes;

    public static function list_all()
    {
    	return self::orderBy('id', 'DESC')->get();
    }

    static function modify_order($id, $data, $action)
    {
        $order_detail = self::find($id);
        if($order_detail)
        {
            switch ($action)
            {
                case 'update':
                    $order_detail->date_written = $data['date_written'];
                    $order_detail->origination_id = $data['origination_id'];
                    $order_detail->date_picked_up = $data['date_picked_up'] ? date('Y-m-d H:i:s', strtotime($data['date_picked_up'])) : null;
                    $order_detail->order_picked_up_at = $data['order_picked_up_at'];
                    $order_detail->is_partial_order = $data['is_partial_order'];
                    $order_detail->status = $data['status'];
                    break;

                case 'delete':
                    $order_detail->status = Config::get('constants.status.inactive');
                    $order_detail->deleted_at = date('Y-m-d H:i:s');
                    break;
                
                default:
                    # code...
                    break;
            }

            try
            {
                $order_detail->updated_at = date('Y-m-d H:i:s');
                $order_detail->save();

                return true;
            }
            catch (\Exception $e)
            {
                #code...
            }
        }

        return false;
    }
}
