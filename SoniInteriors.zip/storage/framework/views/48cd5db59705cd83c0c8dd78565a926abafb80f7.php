<?php $__env->startSection('content'); ?>
<div class="login-wrapper ">
    <div class="bg-pic">
        <img src="<?php echo e(URL::asset('backend/img/demo/new-york-city-buildings-sunrise-morning-hd-wallpaper.png')); ?>" data-src="<?php echo e(URL::asset('backend/img/demo/new-york-city-buildings-sunrise-morning-hd-wallpaper.png')); ?>" data-src-retina="<?php echo e(URL::asset('backend/img/demo/new-york-city-buildings-sunrise-morning-hd-wallpaper.png')); ?>" alt="" class="lazy">

        <div class="bg-caption pull-bottom sm-pull-bottom text-white p-l-20 m-b-20">
            <h2 class="semi-bold text-white"><?php echo e(Config::get('app.name')); ?></h2>
            <p class="small">images Displayed are solely for representation purposes only, All work copyright of respective owner, otherwise © <?php echo e(date('Y')); ?> DuckTale IT Services.</p>
        </div>
    </div>

    <div class="login-container bg-white">
        <div class="p-l-50 m-l-20 p-r-50 m-r-20 p-t-50 m-t-30 sm-p-l-15 sm-p-r-15 sm-p-t-40">
            <img src="<?php echo e(URL::asset('backend/img/logo.png')); ?>" alt="logo" data-src="<?php echo e(URL::asset('backend/img/logo.png')); ?>" data-src-retina="<?php echo e(URL::asset('backend/img/logo_2x.png')); ?>" width="78" height="22">
            <p class="p-t-35">Sign into your account</p>

            <form id="form-login" class="p-t-15" role="form" action="<?php echo e(route('admin_login')); ?>" method="POST">
                <div class="form-group form-group-default">
                    <label>Login</label>
                    <div class="controls">
                        <input type="text" name="email" placeholder="Email Address" class="form-control" required>
                        <?php echo csrf_field(); ?>
                    </div>
                </div>

                <div class="form-group form-group-default">
                    <label>Password</label>
                    <div class="controls">
                        <input type="password" class="form-control" name="password" placeholder="Credentials" required>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6 no-padding sm-p-l-10">
                        <div class="checkbox ">
                            <input type="checkbox" id="checkbox1" name="remember">
                            <label for="checkbox1">Keep Me Signed in</label>
                        </div>
                    </div>
                </div>
                <button class="btn btn-primary btn-cons m-t-10" type="submit">Sign in</button>
                <?php if(Session::has('message')): ?>
                    <p class="alert alert-<?php echo e(Session::get('alert-class')); ?>"><?php echo e(Session::get('message')); ?></p>
                <?php endif; ?>
            </form>

            <div class="pull-bottom sm-pull-bottom">
                <div class="m-b-30 p-r-80 sm-m-t-20 sm-p-r-15 sm-p-b-20 clearfix">
                    <div class="col-sm-12 no-padding m-t-10 text-center">
                        <p class="small no-margin pull-right sm-pull-reset">
                            Hand-crafted <span class="hint-text">&amp; made with Love in</span> <img class="footer-flag" src="<?php echo e(URL::asset('backend/img/india-flag-icon-16.png')); ?>"> <span>by</span> <a href="http://www.ducktaleit.com" target="_blank">DuckTale IT Services.</a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('#form-login').validate();
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>