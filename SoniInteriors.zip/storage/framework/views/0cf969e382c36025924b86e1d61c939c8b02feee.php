<?php $__env->startSection('content'); ?>
<link href="<?php echo e(URL::asset('backend/plugins/bootstrap-datepicker/css/datepicker3.css')); ?>" rel="stylesheet" type="text/css" />
<script src="<?php echo e(URL::asset('backend/plugins/bootstrap-datepicker/js/bootstrap-datepicker.js')); ?>" type="text/javascript"></script>

<div data-pages="parallax">
    <div class="container-fluid pull-left p-l-25 p-r-25 sm-p-l-0 sm-p-r-0">
        <div class="inner">
            <ol class="breadcrumb sm-p-b-5 pull-left">
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('admin_dashboard')); ?>">Dashboard</a>
                </li>
                <li class="breadcrumb-item">
                    <a href="<?php echo e(route('admin_orders')); ?>">Orders</a>
                </li>
                <li class="breadcrumb-item active">Edit</li>
            </ol>
        </div>
    </div>
</div>
<div class="container-fluid content-body-page container-fixed-lg bg-white pull-left" 
    data-notif-msg="<?php echo e(Session::has('message') ? Session::get('message') : ''); ?>" 
    data-notif-cls="<?php echo e(Session::has('alert-class') ? Session::get('alert-class') : ''); ?>">
    <div class="row">
        <div class="col-8">
            <div class="row">
                <div class="card card-transparent">
                    <div class="card-body px-0">
                        <form action="<?php echo e(route('admin_add_order')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <label for="date_written" class="col-md-4 control-label">Date Written</label>
                                <div class="col-md-8">
                                    <div id="datepicker_date_written" class="input-group date">
                                        <input class="form-control" id="date_written" name="date_written" required="" type="text" value="<?php echo e(old('date_written')); ?>" value="<?php echo e($order_details['date_written'] ? date('m-d-Y', strtotime($order_details['date_written'])) : ''); ?>">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i>
                                        </span>
                                    </div>
                                    <?php if(isset($errors) && $errors->has('date_written')): ?>
                                        <label id="date_written-error" class="error" for="date_written"><?php echo e($errors->first('date_written')); ?></label>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-4 control-label">Origination</label>
                                <div class="col-md-8">
                                    <div class="radio radio-success">
                                        <select class="full-width" data-init-plugin="select2" name="origination">
                                            <?php $__currentLoopData = $originations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->origination_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php if(isset($errors) && $errors->has('origination')): ?>
                                        <label id="origination-error" class="error" for="origination"><?php echo e($errors->first('origination')); ?></label>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="date_picked_up " class="col-md-4 control-label">Date Picked up</label>
                                <div class="col-md-8">
                                    <div id="datepicker_date_written" class="input-group date">
                                        <input class="form-control" id="date_picked_up " name="date_picked_up" required="" type="text" value="<?php echo e(old('date_picked_up ')); ?>">
                                        <span class="input-group-addon"><i class="fa fa-calendar"></i>
                                        </span>
                                    </div>
                                    <?php if(isset($errors) && $errors->has('date_picked_up ')): ?>
                                        <label id="date_picked_up -error" class="error" for="date_picked_up "><?php echo e($errors->first('date_picked_up ')); ?></label>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label for="date_picked_up" class="col-md-4 control-label">Picked Up At</label>
                                <div class="col-md-8">
                                    <div class="radio radio-success">
                                        <select class="full-width" data-init-plugin="select2" name="order_picked_up_at">
                                            <?php $__currentLoopData = $picked_up_at; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value->id); ?>"><?php echo e($value->picked_up_at); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php if(isset($errors) && $errors->has('picked_up_at')): ?>
                                        <label id="picked_up_at-error" class="error" for="picked_up_at"><?php echo e($errors->first('picked_up_at')); ?></label>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-4 control-label">Is Partial Order</label>
                                <div class="col-md-8">
                                    <div class="radio radio-success">
                                        <select class="full-width" data-init-plugin="select2" name="is_partial_order">
                                            <option value="1">Yes</option>
                                            <option value="0">No</option>
                                        </select>
                                    </div>
                                    <?php if(isset($errors) && $errors->has('is_partial_order')): ?>
                                        <label id="is_partial_order-error" class="error" for="is_partial_order"><?php echo e($errors->first('is_partial_order')); ?></label>
                                    <?php endif; ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <label class="col-md-4 control-label">Status</label>
                                <div class="col-md-8">
                                    <div class="radio radio-success">
                                        <select class="full-width" data-init-plugin="select2" name="status">
                                            <?php $__currentLoopData = Config::get('constants.status'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($value); ?>"><?php echo e(ucfirst($key)); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <?php if(isset($errors) && $errors->has('status')): ?>
                                        <label id="status-error" class="error" for="status"><?php echo e($errors->first('status')); ?></label>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <br>
                            <div class="row">
                                <div class="col-md-12">
                                    <input type="submit" class="btn btn-success" value="Save" name="submit">
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
$(document).ready(function() {
    $('.date').datepicker({
        format: 'mm-dd-yyyy'
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>